"""
Liquidity Sweep Trading Bot - Binance Futures
Supports Testnet / Live switching via config
"""

import os, time, json, math, logging, sys
from datetime import datetime
from dataclasses import dataclass, field, asdict
from typing import Optional
import threading

try:
    from binance.um_futures import UMFutures
    from binance.error import ClientError
except ImportError:
    raise ImportError("Run: pip install binance-futures-connector")

try:
    import pandas as pd
    import numpy as np
except ImportError:
    raise ImportError("Run: pip install pandas numpy")

# ─── Logging ────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger("SweepBot")


# ─── Config ──────────────────────────────────────────────────────────────────
@dataclass
class BotConfig:
    # Credentials — set via Railway env vars or config.json
    api_key: str = ""
    api_secret: str = ""

    # Mode — set LIVE_MODE=true in Railway env to go live
    live_mode: bool = False

    def __post_init__(self):
        # Environment variables override blank config values
        if not self.api_key:
            self.api_key = os.environ.get("BINANCE_API_KEY", "")
        if not self.api_secret:
            self.api_secret = os.environ.get("BINANCE_API_SECRET", "")
        env_live = os.environ.get("LIVE_MODE", "")
        if env_live:
            self.live_mode = env_live.lower() == "true"

    # Capital & Risk
    total_capital: float = 10.0      # USD
    risk_per_trade: float = 0.02     # 2% per trade
    max_leverage: int = 10
    max_open_trades: int = 2

    # Strategy params
    pivot_len: int = 5
    fvg_lookback: int = 3
    min_body_ratio: float = 0.35
    rejection_ratio: float = 1.5
    sweep_cooldown: int = 12
    tp_ratio: float = 2.0            # RR ratio
    sl_buffer: float = 0.002         # 0.2% buffer beyond sweep

    # Pair selection
    top_n_pairs: int = 5             # How many pairs to scan
    volume_threshold: float = 50_000_000  # Minimum 24h volume

    # Timing
    scan_interval: int = 60          # seconds between scans
    kline_interval: str = "15m"
    klines_limit: int = 100

    # Testnet URLs
    testnet_base_url: str = "https://testnet.binancefuture.com"
    live_base_url: str = "https://fapi.binance.com"


@dataclass
class Trade:
    symbol: str
    direction: str          # "LONG" | "SHORT"
    entry: float
    sl: float
    tp: float
    size: float             # contracts
    notional: float
    open_time: str
    status: str = "OPEN"   # OPEN | TP | SL | MANUAL
    close_price: float = 0.0
    pnl: float = 0.0
    order_id: str = ""


# ─── Market Data ─────────────────────────────────────────────────────────────
class MarketData:
    def __init__(self, client: UMFutures):
        self.client = client

    def get_top_pairs(self, n: int, min_volume: float) -> list[str]:
        """Return top N USDT pairs by 24h volume above threshold."""
        try:
            tickers = self.client.ticker_24hr_price_change()
            usdt = [
                t for t in tickers
                if t["symbol"].endswith("USDT")
                and not any(x in t["symbol"] for x in ["BUSD", "USDC", "TUSD"])
                and float(t["quoteVolume"]) >= min_volume
            ]
            usdt.sort(key=lambda x: float(x["quoteVolume"]), reverse=True)
            symbols = [t["symbol"] for t in usdt[:n]]
            log.info(f"Top pairs selected: {symbols}")
            return symbols
        except Exception as e:
            log.error(f"Error fetching pairs: {e}")
            return ["BTCUSDT", "ETHUSDT"]

    def get_klines(self, symbol: str, interval: str, limit: int) -> pd.DataFrame:
        try:
            raw = self.client.klines(symbol, interval, limit=limit)
            df = pd.DataFrame(raw, columns=[
                "open_time","open","high","low","close","volume",
                "close_time","quote_vol","trades","taker_buy_base",
                "taker_buy_quote","ignore"
            ])
            for col in ["open","high","low","close","volume"]:
                df[col] = df[col].astype(float)
            df["open_time"] = pd.to_datetime(df["open_time"], unit="ms")
            return df
        except Exception as e:
            log.error(f"Kline error for {symbol}: {e}")
            return pd.DataFrame()

    def get_price(self, symbol: str) -> float:
        try:
            r = self.client.ticker_price(symbol=symbol)
            return float(r["price"])
        except:
            return 0.0

    def get_symbol_info(self, symbol: str) -> dict:
        try:
            info = self.client.exchange_info()
            for s in info["symbols"]:
                if s["symbol"] == symbol:
                    return s
        except:
            pass
        return {}


# ─── Strategy Engine ─────────────────────────────────────────────────────────
class SweepStrategy:
    def __init__(self, cfg: BotConfig):
        self.cfg = cfg

    def pivot_high(self, series: pd.Series, length: int) -> pd.Series:
        result = pd.Series(np.nan, index=series.index)
        for i in range(length, len(series) - length):
            window = series.iloc[i - length: i + length + 1]
            if series.iloc[i] == window.max():
                result.iloc[i] = series.iloc[i]
        return result

    def pivot_low(self, series: pd.Series, length: int) -> pd.Series:
        result = pd.Series(np.nan, index=series.index)
        for i in range(length, len(series) - length):
            window = series.iloc[i - length: i + length + 1]
            if series.iloc[i] == window.min():
                result.iloc[i] = series.iloc[i]
        return result

    def analyze(self, df: pd.DataFrame) -> Optional[dict]:
        """
        Returns signal dict or None.
        Signal keys: direction, sweep_price, entry, sl, tp
        """
        if df.empty or len(df) < self.cfg.pivot_len * 3:
            return None

        h = df["high"]
        l = df["low"]
        o = df["open"]
        c = df["close"]

        pl = self.cfg.pivot_len
        ph_series = self.pivot_high(h, pl)
        pl_series = self.pivot_low(l, pl)

        # Last confirmed pivots
        last_ph = ph_series.dropna()
        last_pl = pl_series.dropna()

        if last_ph.empty or last_pl.empty:
            return None

        swing_high = last_ph.iloc[-1]
        swing_low  = last_pl.iloc[-1]

        # Current bar (latest complete candle)
        i = len(df) - 1
        hi = h.iloc[i]
        lo = l.iloc[i]
        op = o.iloc[i]
        cl = c.iloc[i]

        body  = abs(cl - op)
        rng   = hi - lo
        if rng == 0:
            return None

        # Displacement
        bull_disp = cl > op and body > rng * self.cfg.min_body_ratio
        bear_disp = cl < op and body > rng * self.cfg.min_body_ratio

        # Rejection wicks
        bull_rej = (cl - lo) > (hi - cl) * self.cfg.rejection_ratio
        bear_rej = (hi - cl) > (cl - lo) * self.cfg.rejection_ratio

        # FVG on last N bars
        fvg_bull = any(
            df["low"].iloc[j] > df["high"].iloc[j - 1]
            for j in range(max(1, i - self.cfg.fvg_lookback), i + 1)
        )
        fvg_bear = any(
            df["high"].iloc[j] < df["low"].iloc[j - 1]
            for j in range(max(1, i - self.cfg.fvg_lookback), i + 1)
        )

        # Sweep conditions
        bull_sweep = lo < swing_low and cl > swing_low and bull_rej and bull_disp
        bear_sweep = hi > swing_high and cl < swing_high and bear_rej and bear_disp

        buf = self.cfg.sl_buffer

        if bull_sweep and fvg_bull:
            sl = swing_low * (1 - buf)
            risk = cl - sl
            tp = cl + risk * self.cfg.tp_ratio
            return {
                "direction": "LONG",
                "sweep_price": swing_low,
                "entry": cl,
                "sl": sl,
                "tp": tp,
                "risk_pct": risk / cl
            }

        if bear_sweep and fvg_bear:
            sl = swing_high * (1 + buf)
            risk = sl - cl
            tp = cl - risk * self.cfg.tp_ratio
            return {
                "direction": "SHORT",
                "sweep_price": swing_high,
                "entry": cl,
                "sl": sl,
                "tp": tp,
                "risk_pct": risk / cl
            }

        return None


# ─── Risk Manager ─────────────────────────────────────────────────────────────
class RiskManager:
    def __init__(self, cfg: BotConfig):
        self.cfg = cfg

    def position_size(self, entry: float, sl: float, capital: float) -> tuple[float, float]:
        """Returns (qty, notional)"""
        risk_usd = capital * self.cfg.risk_per_trade
        sl_dist  = abs(entry - sl)
        if sl_dist == 0:
            return 0, 0
        qty = risk_usd / sl_dist
        notional = qty * entry
        # Leverage cap
        max_notional = capital * self.cfg.max_leverage
        if notional > max_notional:
            qty = max_notional / entry
            notional = max_notional
        return round(qty, 4), round(notional, 2)

    def round_qty(self, qty: float, step: float) -> float:
        if step == 0:
            return qty
        precision = int(round(-math.log10(step)))
        return round(math.floor(qty / step) * step, precision)


# ─── Order Executor ───────────────────────────────────────────────────────────
class OrderExecutor:
    def __init__(self, client: UMFutures, cfg: BotConfig):
        self.client = client
        self.cfg = cfg
        self.rm = RiskManager(cfg)

    def set_leverage(self, symbol: str, leverage: int):
        try:
            self.client.change_leverage(symbol=symbol, leverage=leverage)
        except Exception as e:
            log.warning(f"Leverage set failed for {symbol}: {e}")

    def get_step_size(self, symbol: str) -> float:
        try:
            info = self.client.exchange_info()
            for s in info["symbols"]:
                if s["symbol"] == symbol:
                    for f in s["filters"]:
                        if f["filterType"] == "LOT_SIZE":
                            return float(f["stepSize"])
        except:
            pass
        return 0.001

    def open_trade(self, symbol: str, signal: dict, capital: float) -> Optional[Trade]:
        direction = signal["direction"]
        entry     = signal["entry"]
        sl        = signal["sl"]
        tp        = signal["tp"]

        qty, notional = self.rm.position_size(entry, sl, capital)
        if qty <= 0 or notional < 5:
            log.warning(f"{symbol}: Notional too small (${notional:.2f}), skipping")
            return None

        step = self.get_step_size(symbol)
        qty  = self.rm.round_qty(qty, step)
        if qty <= 0:
            return None

        side      = "BUY"  if direction == "LONG"  else "SELL"
        sl_side   = "SELL" if direction == "LONG"  else "BUY"
        tp_side   = "SELL" if direction == "LONG"  else "BUY"

        self.set_leverage(symbol, self.cfg.max_leverage)

        try:
            # Market entry
            order = self.client.new_order(
                symbol=symbol,
                side=side,
                type="MARKET",
                quantity=qty
            )
            order_id = str(order.get("orderId", ""))

            # Stop Loss
            self.client.new_order(
                symbol=symbol,
                side=sl_side,
                type="STOP_MARKET",
                stopPrice=round(sl, 4),
                closePosition=True
            )

            # Take Profit
            self.client.new_order(
                symbol=symbol,
                side=tp_side,
                type="TAKE_PROFIT_MARKET",
                stopPrice=round(tp, 4),
                closePosition=True
            )

            trade = Trade(
                symbol=symbol,
                direction=direction,
                entry=entry,
                sl=round(sl, 4),
                tp=round(tp, 4),
                size=qty,
                notional=notional,
                open_time=datetime.utcnow().isoformat(),
                order_id=order_id
            )
            log.info(f"✅ {direction} opened on {symbol} @ {entry} | SL:{sl:.4f} TP:{tp:.4f} | Qty:{qty}")
            return trade

        except ClientError as e:
            log.error(f"Order failed {symbol}: {e.error_message}")
            return None
        except Exception as e:
            log.error(f"Order error {symbol}: {e}")
            return None

    def close_trade(self, trade: Trade, reason: str = "MANUAL") -> float:
        side = "SELL" if trade.direction == "LONG" else "BUY"
        try:
            self.client.new_order(
                symbol=trade.symbol,
                side=side,
                type="MARKET",
                quantity=trade.size,
                reduceOnly=True
            )
            log.info(f"❌ Closed {trade.symbol} ({reason})")
        except Exception as e:
            log.error(f"Close failed {trade.symbol}: {e}")
        return 0.0


# ─── State / Journal ──────────────────────────────────────────────────────────
class TradingJournal:
    def __init__(self, path="trades.json"):
        self.path = path
        self.trades: list[Trade] = []
        self._load()

    def _load(self):
        try:
            with open(self.path) as f:
                data = json.load(f)
                self.trades = [Trade(**t) for t in data]
        except:
            self.trades = []

    def save(self):
        with open(self.path, "w") as f:
            json.dump([asdict(t) for t in self.trades], f, indent=2)

    def add(self, trade: Trade):
        self.trades.append(trade)
        self.save()

    def update(self, trade: Trade):
        self.save()

    def open_trades(self) -> list[Trade]:
        return [t for t in self.trades if t.status == "OPEN"]

    def stats(self) -> dict:
        closed = [t for t in self.trades if t.status != "OPEN"]
        wins   = [t for t in closed if t.pnl > 0]
        total_pnl = sum(t.pnl for t in closed)
        return {
            "total":     len(closed),
            "wins":      len(wins),
            "losses":    len(closed) - len(wins),
            "win_rate":  len(wins) / len(closed) if closed else 0,
            "total_pnl": round(total_pnl, 4),
            "open":      len(self.open_trades())
        }


# ─── Bot Core ────────────────────────────────────────────────────────────────
class LiquiditySweepBot:
    def __init__(self, cfg: BotConfig, trades_path: str = "trades.json"):
        self.cfg = cfg
        self.running = False
        self.journal = TradingJournal(trades_path)
        self.strategy = SweepStrategy(cfg)

        base_url = cfg.live_base_url if cfg.live_mode else cfg.testnet_base_url
        self.client = UMFutures(
            key=cfg.api_key,
            secret=cfg.api_secret,
            base_url=base_url
        )
        self.market  = MarketData(self.client)
        self.executor = OrderExecutor(self.client, cfg)
        self.capital  = cfg.total_capital
        self._status  = "IDLE"
        self._last_scan = None
        self._scanned_pairs = []

        mode = "🔴 LIVE" if cfg.live_mode else "🟡 TESTNET"
        log.info(f"Bot initialized in {mode} mode with ${cfg.total_capital} capital")

    @property
    def status(self) -> str:
        return self._status

    def get_account_balance(self) -> float:
        try:
            balances = self.client.balance()
            for b in balances:
                if b["asset"] == "USDT":
                    return float(b["availableBalance"])
        except Exception as e:
            log.warning(f"Balance fetch failed: {e}")
        return self.capital

    def scan_and_trade(self):
        self._status = "SCANNING"
        open_trades = self.journal.open_trades()

        if len(open_trades) >= self.cfg.max_open_trades:
            self._status = "MAX_TRADES"
            return

        self.capital = self.get_account_balance()
        symbols = self.market.get_top_pairs(self.cfg.top_n_pairs, self.cfg.volume_threshold)
        self._scanned_pairs = symbols

        # Skip already-traded symbols
        open_symbols = {t.symbol for t in open_trades}

        for symbol in symbols:
            if symbol in open_symbols:
                continue
            df = self.market.get_klines(symbol, self.cfg.kline_interval, self.cfg.klines_limit)
            signal = self.strategy.analyze(df)

            if signal:
                log.info(f"🎯 Signal on {symbol}: {signal['direction']} | Entry:{signal['entry']:.4f}")
                trade = self.executor.open_trade(symbol, signal, self.capital)
                if trade:
                    self.journal.add(trade)
                    open_trades.append(trade)
                    if len(open_trades) >= self.cfg.max_open_trades:
                        break

        self._last_scan = datetime.utcnow().isoformat()
        self._status = "WATCHING"

    def monitor_trades(self):
        """Update open trade status by checking current prices."""
        for trade in self.journal.open_trades():
            price = self.market.get_price(trade.symbol)
            if price == 0:
                continue

            hit_tp = (trade.direction == "LONG"  and price >= trade.tp) or \
                     (trade.direction == "SHORT" and price <= trade.tp)
            hit_sl = (trade.direction == "LONG"  and price <= trade.sl) or \
                     (trade.direction == "SHORT" and price >= trade.sl)

            if hit_tp:
                pnl = abs(trade.tp - trade.entry) * trade.size
                trade.status = "TP"
                trade.close_price = trade.tp
                trade.pnl = round(pnl, 4)
                self.capital += pnl
                log.info(f"🏆 TP HIT {trade.symbol} | PnL: +${pnl:.4f}")
                self.journal.update(trade)

            elif hit_sl:
                pnl = -abs(trade.entry - trade.sl) * trade.size
                trade.status = "SL"
                trade.close_price = trade.sl
                trade.pnl = round(pnl, 4)
                self.capital += pnl
                log.info(f"💀 SL HIT {trade.symbol} | PnL: ${pnl:.4f}")
                self.journal.update(trade)

    def get_dashboard_state(self) -> dict:
        stats = self.journal.stats()
        open_t = self.journal.open_trades()
        recent = sorted(self.journal.trades, key=lambda x: x.open_time, reverse=True)[:20]
        return {
            "mode": "LIVE" if self.cfg.live_mode else "TESTNET",
            "status": self._status,
            "capital": round(self.capital, 4),
            "last_scan": self._last_scan,
            "scanned_pairs": self._scanned_pairs,
            "stats": stats,
            "open_trades": [asdict(t) for t in open_t],
            "recent_trades": [asdict(t) for t in recent],
            "config": {
                "risk_per_trade": self.cfg.risk_per_trade,
                "max_leverage": self.cfg.max_leverage,
                "tp_ratio": self.cfg.tp_ratio,
                "interval": self.cfg.kline_interval,
                "max_open": self.cfg.max_open_trades,
            }
        }

    def run_loop(self):
        self.running = True
        log.info("🚀 Bot loop started")
        while self.running:
            try:
                self.monitor_trades()
                self.scan_and_trade()
            except Exception as e:
                log.error(f"Loop error: {e}")
                self._status = "ERROR"
            time.sleep(self.cfg.scan_interval)

    def start(self):
        t = threading.Thread(target=self.run_loop, daemon=True)
        t.start()

    def stop(self):
        self.running = False
        self._status = "STOPPED"
        log.info("Bot stopped.")
