# 🚂 Deploy to Railway — Step by Step

## Prerequisites
- GitHub account (free)
- Railway account (free) → https://railway.app
- Your Binance LIVE API keys

---

## Step 1 — Create a GitHub repo

1. Go to https://github.com/new
2. Name it: `sweep-bot` (private recommended)
3. Click **Create repository**

---

## Step 2 — Push your bot files

Open a terminal in the `bot/` folder and run:

```bash
git init
git add .
git commit -m "Initial sweep bot"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/sweep-bot.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username.

---

## Step 3 — Deploy on Railway

1. Go to https://railway.app → **New Project**
2. Click **Deploy from GitHub repo**
3. Select your `sweep-bot` repo
4. Railway auto-detects Python and starts building

---

## Step 4 — Set Environment Variables (CRITICAL for security)

In your Railway project → **Variables** tab → Add these:

| Variable | Value |
|----------|-------|
| `BINANCE_API_KEY` | Your live Binance API key |
| `BINANCE_API_SECRET` | Your live Binance API secret |
| `LIVE_MODE` | `false` ← start with testnet! |

⚠️ **Never put your API keys in code or config.json** — use env vars only.

---

## Step 5 — Get your public URL

1. Railway project → **Settings** tab → **Domains**
2. Click **Generate Domain**
3. You get a URL like: `https://sweep-bot-production.up.railway.app`
4. Open it — your dashboard is live 24/7 🎉

---

## Step 6 — Go Live (when ready)

1. In Railway → Variables → change `LIVE_MODE` to `true`
2. Railway auto-restarts the bot
3. Dashboard will show 🔴 LIVE badge
4. Bot will start scanning real markets

---

## Monitoring

- **Logs**: Railway project → **Deployments** → click deploy → **View Logs**
- **Dashboard**: Your Railway URL anytime from any device
- **Restart**: Railway → redeploy if anything goes wrong

---

## Free Tier Limits

Railway free tier gives you **$5 credit/month** which covers ~500 hours.
For 24/7 uptime (~720 hrs/month) you need the **Hobby plan at $5/month**.

---

## Security Checklist

- [x] API keys in env vars, NOT in code
- [x] Repo set to **private** on GitHub
- [ ] Binance API key has **Futures trading only** enabled
- [ ] Binance API key has your Railway server IP whitelisted (optional but safer)
- [ ] Start with `LIVE_MODE=false` and verify on testnet first

---

## Troubleshooting

**Build fails**: Check Railway logs — usually a missing package
**Bot not trading**: Check logs for "Notional too small" — capital too low
**API error 401**: Wrong API keys or keys don't have Futures permission
**No signals**: Normal — strategy is strict. Check on higher-volume pairs.
